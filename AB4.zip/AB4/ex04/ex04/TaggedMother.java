package ex04;

public interface TaggedMother {
    public String getTokenTag(int position);
    public int getLength();
    public String getTokenText(int position);
}
