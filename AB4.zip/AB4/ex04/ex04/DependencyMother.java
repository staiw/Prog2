package ex04;

public interface DependencyMother {
    public int getTokenHead(int position);
    public String getTokenRel(int position);
    public int getLength();
}
