package ex04;

public interface TaggableMother {
    public void setTokenTag(int position, String value);
    public int getLength();
}
