package ex04;

public interface TokenMother {
    public String getTokenText(int position);
    public int getLength();
}
